public class queueException extends RuntimeException {
    public queueException (String errorMess) {
        super(errorMess);
    }
}
