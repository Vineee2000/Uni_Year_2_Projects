/**
 * interface for exercise 6
 */
public interface LListIterator <T>
{
    public boolean hasNext();
    public T next();
    public void remove();
}